package com.example.pokemon;

public class pokemon {
    String name = "pikachu";
    int image ;
    int attack;
    int defence ;
    int total ;
}
